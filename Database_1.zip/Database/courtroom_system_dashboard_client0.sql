CREATE DATABASE  IF NOT EXISTS `courtroom_system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `courtroom_system`;
-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: courtroom_system
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dashboard_client`
--

DROP TABLE IF EXISTS `dashboard_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_client` (
  `Name` varchar(45) NOT NULL,
  `Email` varchar(254) NOT NULL,
  `ContactNo` int NOT NULL,
  `City` varchar(45) NOT NULL,
  `Street` varchar(45) NOT NULL,
  `Pincode` int NOT NULL,
  `Password` varchar(20) NOT NULL,
  `LawyerEmail_id` varchar(254) NOT NULL,
  `ApprovalStatus` int NOT NULL,
  PRIMARY KEY (`Email`),
  UNIQUE KEY `Email_UNIQUE` (`Email`),
  KEY `dashboard_client_LawyerEmail_id_553a6808_fk_dashboard` (`LawyerEmail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_client`
--

LOCK TABLES `dashboard_client` WRITE;
/*!40000 ALTER TABLE `dashboard_client` DISABLE KEYS */;
INSERT INTO `dashboard_client` VALUES ('Aurora','aurie@hotmail.com',956783978,'Vegas','UJ Street',900341,'aurie67','kavs@gamil.com',1),('Belle','belle6@gmail.com',869567367,'Washington','Queens Lane',923004,'belle9','kavs@gmail.com',0),('Bruce Banner','bruceb8@yahoo.com',985475867,'London','SQ Road',110001,'brucebanner','lali12@gmail.com',1),('Camila Cabello','camillacabs@gmail.com',884574574,'England','Ikea Palace',800268,'camscabello','khooshrin2@gmail.com',0),('Chloe','chloe22@yahoo.com',734736574,'Florida','Heaven Road',924990,'chloe22','starm4@yahoo.com',1),('Christine Palmer','christinep@yahoo.com',384283378,'Vegas','Mark Harbour',120005,'palmerchris','stephen@gmail.com',1),('Demi Lovato','demi3@gmail.com',743687356,'Sweden','Park Avenue',700233,'demi7','',0),('Diva','Diva34@gmail.com',564674586,'Mumbai','WE Road',940002,'diva67','tomh5@gmail.com',0),('Divya','divyaj@hotmail.com',746476546,'Miami','Music Street',840089,'divya86','',0),('Diya','diya79@gmail.com',458734687,'Delhi','Westside Lane',900454,'diya98','pepper@gmail.com',0),('Harvey','harvey69@hotmail.com',578376757,'Hawai','RE Road',849931,'harvey66','pepper@gmail.com',1),('Hemangi','hemb@gmail.com',878703232,'Bangalore','JP Street',870021,'hemangidb','khooshrin2@gmail.com',1),('Jasmin','jassy@gmail.com',749586566,'Hawai','Hawa Lane',478001,'jasmin9','',0),('Khooshnaz','khoosh@hotmail.com',934747128,'Mumbai','SC Marg',400023,'khoosh2','tony@hotmail.com',1),('Lucas','luc@gmail.com',891357392,'California','Cal Road',900123,'lucas99','kavs@hotmail.com',1),('Maaz','maaz23@gmail.com',476386548,'Russia','LK Street',890048,'maaz67','starm4@yahoo.com',1),('Madhumita','madz@yahoo.com',743841893,'Pune','Laal Chowk',600012,'madhup0','lali12@gmail.com',1),('Mary Jane','maryjane@gmail.com',493895965,'New York','Bridgeton Road',122089,'mj1029','peterp@hotmail.com',1),('Medini','meds7@gmail.com',846786787,'Holland','QW Road',850578,'medini97','starm4@yahoo.com',1),('Micheal','michael45@gmail.com',845774657,'Miami','ET Lane',875847,'michael22','peterp@hotmail.com',0),('Mike','mike3@gmail.com',587665767,'California','YH Road',859853,'mike44','peterp@hotmail.com',1),('Sam Wilson','samwilson@gmail.com',234657688,'Washington','WC Avenue',233001,'samwilson3','pepper@hotmail.com',1),('Scarlett Johan','scarjo@hotmail.com',146788997,'New York','Fight Street',900022,'scarjo66','tony@hotmail.com',1),('Selena Gomez','selenagom@gmail.com',812348621,'Hollywood','Famous Lane',900101,'selenagomz','lali12@gmail.com',1),('Shawn Mendes','shawnmendes@hotmail.com',876595768,'Canada','QT Lane',802457,'shawnmendes','khooshrin2@gmail.com',1),('Spectre','spectre555@gmail.com',358787456,'Bangalore','HK Lane',890068,'spectre5','stephen@gmail.com',1),('Steve Rogers','steverog@gmail.com',298385868,'Britain','KL Road',270012,'steverog2','tony@hotmail.com',1),('Taylor Swift','taylor5@hotmail.com',845855486,'Texas','Right Avenue',900101,'swift5','tomh5@gmail.com',1);
/*!40000 ALTER TABLE `dashboard_client` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-27 22:39:59
